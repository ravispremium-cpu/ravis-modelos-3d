# Modelos 3D de músculos — Ravis Fit Pro

Modelos anatômicos derivados do **Z-Anatomy** (https://github.com/Z-Anatomy/Models-of-human-anatomy), licenciado sob **CC BY-SA 4.0** (https://creativecommons.org/licenses/by-sa/4.0/), que por sua vez se baseia no **BodyParts3D**, © The Database Center for Life Science, licenciado sob CC BY-SA 2.1 Japão.

> RASCUNHO — conferir o README do repositório de origem e obter orientação jurídica antes de publicar.

## Arquivos

| Arquivo | Conteúdo | Tamanho |
|---|---|---|
| `muscles.min.glb` | 112 malhas (55 músculos, lados direito e esquerdo), 25% dos polígonos, meshopt | 950.252 bytes |
| `muscles.low.glb` | Mesmo conjunto com 10% dos polígonos, meshopt | 475.156 bytes |

SHA-256:

```
4a317c6f8754ddee8568daaf06679cdb580c7239237dc81e0e64de8c60b73546  muscles.min.glb
6f81edbbb6a3b33b381003502278feaec01037c8d5504b0a5507def0cd4205c3  muscles.low.glb
```

## Modificações em relação à origem

- Seleção de malhas musculares do modelo masculino (componentes com licença não comercial do pacote não foram usados).
- Simplificação de polígonos, remoção da hierarquia de grupos e renomeação dos nós para `muscle-<id>-<l|r>-<n>`.
- Exportação em GLB, quantização e compressão meshopt (EXT_meshopt_compression, KHR_mesh_quantization).

## Licença dos arquivos derivados

Estes arquivos derivados são distribuídos sob **CC BY-SA 4.0**, com atribuição ao Z-Anatomy e ao BodyParts3D.

## Limitações

Somente modelo masculino; sem cabeça, mãos, pés, antebraços, pescoço e tensor da fáscia lata.
