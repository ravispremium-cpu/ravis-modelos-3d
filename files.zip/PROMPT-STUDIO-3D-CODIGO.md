# PROMPT — VISUALIZADOR ANATÔMICO 3D: APLICAR O CÓDIGO (SEM ENVIO DE ARQUIVOS) — RAVIS FIT PRO

Este prompt traz o código completo em texto. Não há anexos. Os dois modelos 3D (arquivos .glb) não vão no prompt: serão baixados por URL no PASSO 3.

>>> PREENCHER (pode ficar em branco agora; veja o PASSO 3) <<<
URL_GLB_PADRAO = COLE_AQUI_A_URL_DIRETA_DO_muscles.min.glb
URL_GLB_ECONOMIA = COLE_AQUI_A_URL_DIRETA_DO_muscles.low.glb
>>> FIM DO BLOCO A PREENCHER <<<
Se um valor ainda contiver o texto "COLE_AQUI", trate-o como não informado.

## PASSO -1 — VERIFICAÇÃO DE PROJETO (obrigatória, antes de qualquer ação)
1. Imprima "name" e "version" do package.json e rode:
   ls src/data/muscleTaxonomy.ts src/data/exerciseLibraryData.ts src/components/exercise-detail/ExerciseDetailPage.tsx scripts/verifyLibrary.ts
   Se algum arquivo não existir, PARE e informe.
2. Rode `npm ls three` (esperado 0.185.x) e
   ls node_modules/three/examples/jsm/loaders/GLTFLoader.js node_modules/three/examples/jsm/controls/OrbitControls.js node_modules/three/examples/jsm/libs/meshopt_decoder.module.js
   Se a versão ou algum caminho divergir, PARE e informe.
3. Confirme que cada trecho "ANTIGO" das edições E1 a E5 (PASSO 2) ocorre exatamente uma vez em src/components/exercise-detail/ExerciseDetailPage.tsx. Se algum não ocorrer exatamente uma vez, PARE e informe qual.

## PAPEL E ESCOPO
Engenheiro sênior front-end. Escopo único: aplicar, sem alterações, o código abaixo do visualizador anatômico 3D (modelo de referência masculino, derivado do Z-Anatomy/BodyParts3D, CC BY-SA 4.0). Não reformate, não "melhore", não acrescente nem remova linhas do código fornecido. Navegação, Busca Global, acessibilidade, Design System, PWA, service worker, dataset e atribuição Wger não podem ser alterados. Nenhum pacote novo. O 3D NÃO pode ser ativado por padrão: o padrão continua o modo imagens (o 3D só abre com ?visual=3d na URL ou localStorage['ravis.visual']='3d').

## PASSO 0 — BASELINE
- Calcule SHA-256 de todos os arquivos do projeto (exceto node_modules e dist) e salve em /tmp/c3d_baseline_hashes.txt (informe o caminho).
- Rode `npm run lint` e `npm run build` e registre o tamanho do chunk principal `dist/assets/index-*.js` (kB e gzip) e do chunk `three.module-*.js`.

## PASSO 1 — CRIAR OS ARQUIVOS NOVOS (cópia exata dos blocos da seção CÓDIGO)
Crie os 8 arquivos listados na seção CÓDIGO, com o conteúdo exato de cada bloco. Depois rode este comando e compare cada hash com a tabela:

python3 -c "import hashlib,sys;[print(hashlib.sha256((open(p,encoding='utf-8').read().replace('\r\n','\n').rstrip()+'\n').encode()).hexdigest(),p) for p in sys.argv[1:]]" src/config/anatomyViewer.ts src/data/muscleMeshMap.ts src/components/exercise-detail/MuscleViewer3D.tsx scripts/glbUtils.ts scripts/listGlbNodes.ts scripts/verifyMuscle3d.ts scripts/smokeGlbLoad.ts docs/licenca-modelos-3d.md

Hashes esperados:
1836332dc67f0c5a6e098b12e48dc7435a5bfbf333378ca27131d98e8eb7ec5b  src/config/anatomyViewer.ts
e995451625a637f6f48e45bde4c703f4018b1dae9b4643b0a34ddac3c3a77ebf  src/data/muscleMeshMap.ts
6046ba5c0f96d322a42c45a174e1dc59f7057edf33300c353d4f145c93b566de  src/components/exercise-detail/MuscleViewer3D.tsx
8ebe7d5056b6b9626a4a400ed5a52a33415cc691653c989990b09f3b69f639ea  scripts/glbUtils.ts
430ec0dc63b99daa7b644befb7ffd941ffbaff7029e1752cbaaf9047f48d02a4  scripts/listGlbNodes.ts
bef6bcd53da2bbdaceab4d0c86f722330cfe578da39df3cad0e83950923b43cb  scripts/verifyMuscle3d.ts
35eadb11fad0b5d3446987f4726eb85d2fd1c6585b100728bb1dfcaaa62088ab  scripts/smokeGlbLoad.ts
767efeed751f79ef749ad7cbad1223818f63b11f4591fbe1f8a9f9f4e2fe7eb2  docs/licenca-modelos-3d.md

Se algum hash divergir, reescreva o arquivo a partir do bloco, sem editar a tabela. Se continuar divergindo, PARE e informe o arquivo e a saída bruta.

## PASSO 2 — EDITAR OS ARQUIVOS EXISTENTES
A) src/components/exercise-detail/ExerciseDetailPage.tsx: aplique as edições E1 a E5 da seção EDIÇÕES, na ordem, trocando o trecho ANTIGO pelo NOVO (cada ANTIGO ocorre uma única vez). Depois da última, rode `npx tsc --noEmit`.
B) package.json: acrescente ao objeto "scripts", sem alterar as demais entradas, exatamente:
   "list:glb": "tsx scripts/listGlbNodes.ts",
   "verify:muscle3d": "tsx scripts/verifyMuscle3d.ts",
   "smoke:glb": "tsx scripts/smokeGlbLoad.ts"

## PASSO 3 — INSTALAR OS MODELOS 3D POR URL (sem zip)
Se URL_GLB_PADRAO e URL_GLB_ECONOMIA estiverem preenchidas:
  mkdir -p public/models
  curl -L --fail -o public/models/muscles.min.glb "<URL_GLB_PADRAO>"
  curl -L --fail -o public/models/muscles.low.glb "<URL_GLB_ECONOMIA>"
  sha256sum public/models/muscles.min.glb public/models/muscles.low.glb
Hashes esperados:
  4a317c6f8754ddee8568daaf06679cdb580c7239237dc81e0e64de8c60b73546  public/models/muscles.min.glb  (950252 bytes)
  6f81edbbb6a3b33b381003502278feaec01037c8d5504b0a5507def0cd4205c3  public/models/muscles.low.glb  (475156 bytes)
Confirme também o cabeçalho glTF versão 2: `head -c 12 public/models/muscles.min.glb | xxd`.
Se algum hash divergir, o arquivo for HTML ou o curl falhar: apague o arquivo baixado, cole a saída bruta (inclusive `file` e os primeiros 200 bytes) e PARE esta etapa; as demais permanecem aplicadas.
Se as URLs NÃO estiverem preenchidas: pule o PASSO 3 e o item de ativos do PASSO 4, e informe "ativos 3D pendentes".

## PASSO 4 — VERIFICAÇÕES
- `npm run lint` (sem erros) e `npm run build`: o chunk principal index-*.js não pode crescer mais de 5 kB em relação ao PASSO 0; o visualizador deve aparecer em chunk próprio (MuscleViewer3D-*.js, cerca de 107 kB) e o chunk three.module-*.js deve ficar igual.
- `npm run verify:library` deve continuar passando.
- Somente com os ativos instalados:
  * `npm run list:glb`: para os dois arquivos, esperado 112 nós, 55 IDs distintos, extensões EXT_meshopt_compression e KHR_mesh_quantization (bytes 950252 e 475156).
  * `npm run verify:muscle3d`: esperado "SUCESSO"; 58 IDs canônicos, 56 com malha e 2 sem (antebraco, tensor_fascia_lata); 69 exercícios com músculos primários 100% com malha.
  * `npm run smoke:glb`: esperado "SUCESSO"; 112 nós, 55 IDs, 138746 vértices (padrão) e 56632 (economia), frente detectada (0, 0, 1).
  * `ls -la dist/models`: os dois GLBs presentes no build.
  Se um script falhar, cole a saída bruta e PARE; não altere dados nem o código fornecido para passar. Divergência apenas nos números esperados (sem falha do script) deve ser relatada, não corrigida.

## PASSO 5 — PROVAS
Compare os hashes de todos os arquivos com /tmp/c3d_baseline_hashes.txt e liste adicionados, removidos e alterados. Esperado: adicionados os 8 arquivos do PASSO 1 e (se instalados) public/models/muscles.min.glb e muscles.low.glb; alterados somente ExerciseDetailPage.tsx e package.json (e package-lock.json só se o npm o regravar; informe). Nenhum outro arquivo pode mudar.

## SAÍDA
Resultados dos passos -1 a 5 com saídas brutas (tabela de hashes, lint, build com tamanhos antes e depois, verificadores), lista de arquivos adicionados/alterados e o que ficou pendente. Pare ao final.

## CRITÉRIO DE ACEITE
Código aplicado com hashes idênticos; lint e build sem erros; chunk principal sem crescimento relevante; padrão do app inalterado sem o parâmetro; nenhum outro arquivo alterado; ativos 3D instalados e verificados (ou declarados pendentes).

## SE ALGO FOR AMBÍGUO
Pare e informe antes de decidir sozinho.

---

# CÓDIGO (cópia exata; um bloco por arquivo)

## ARQUIVO 1 — src/config/anatomyViewer.ts

````typescript
/**
 * Configuração do visualizador anatômico 3D (GLB derivado do Z-Anatomy).
 *
 * Liberação em etapas: o padrão é 'images'. O modo '3d' só ativa com `?visual=3d`
 * na URL ou `localStorage['ravis.visual'] = '3d'`. Trocar o padrão para '3d' é uma
 * decisão do dono do produto, após QA visual e revisão profissional dos músculos.
 */
export type AnatomyViewerMode = 'images' | '3d';
export type AnatomyModelQuality = 'standard' | 'low';

const STORAGE_KEY = 'ravis.visual';

export function getAnatomyViewerMode(): AnatomyViewerMode {
  try {
    if (typeof window !== 'undefined') {
      const query = new URLSearchParams(window.location.search).get('visual');
      if (query === '3d') return '3d';
      if (query === 'images') return 'images';
      if (window.localStorage.getItem(STORAGE_KEY) === '3d') return '3d';
    }
  } catch {
    // storage indisponível (modo privado, política do navegador): segue no padrão
  }
  return 'images';
}

interface NavigatorHints {
  connection?: { saveData?: boolean };
  deviceMemory?: number;
}

/** 'low' em economia de dados ou aparelhos com pouca memória; 'standard' no restante. */
export function pickAnatomyModelQuality(): AnatomyModelQuality {
  if (typeof navigator === 'undefined') return 'standard';
  const nav = navigator as Navigator & NavigatorHints;
  if (nav.connection?.saveData) return 'low';
  if (typeof nav.deviceMemory === 'number' && nav.deviceMemory <= 2) return 'low';
  return 'standard';
}

export function getAnatomyModelUrl(quality: AnatomyModelQuality): string {
  const env = (import.meta as unknown as { env?: { BASE_URL?: string } }).env;
  const base = env?.BASE_URL ?? '/';
  return `${base}models/${quality === 'low' ? 'muscles.low.glb' : 'muscles.min.glb'}`;
}
````

## ARQUIVO 2 — src/data/muscleMeshMap.ts

````typescript
/**
 * Mapeamento CanonicalMuscleId (taxonomia da B2) → nós do GLB anatômico.
 *
 * O GLB (derivado do Z-Anatomy/BodyParts3D, CC BY-SA 4.0) tem nós nomeados
 * `muscle-<id>-<l|r>-<n>`. Os `<id>` abaixo são identificadores de malha escolhidos na
 * extração (ver docs/3d/proto_report.json); NÃO são IDs canônicos da taxonomia.
 *
 * Toda entrada é `needsReview: true`: o recorte e as equivalências anatômicas precisam
 * de revisão por profissional de educação física antes de o 3D virar o padrão do app.
 */
import type { CanonicalMuscleId } from './muscleTaxonomy';

export const GLB_MUSCLE_NODE_IDS = [
  'peitoral_esternocostal', 'peitoral_clavicular', 'peitoral_menor', 'serratil_anterior',
  'latissimo_dorso', 'redondo_maior', 'redondo_menor', 'infraespinhal', 'supraespinhal', 'subescapular',
  'romboide_maior', 'romboide_menor', 'trapezio_superior', 'trapezio_medio', 'trapezio_inferior',
  'iliocostal_lombar', 'longissimo_torax',
  'deltoide_anterior', 'deltoide_lateral', 'deltoide_posterior',
  'biceps_cabeca_longa', 'biceps_cabeca_curta', 'braquial', 'braquiorradial',
  'triceps_cabeca_longa', 'triceps_cabeca_lateral', 'triceps_cabeca_medial', 'anconeo',
  'reto_abdominal', 'obliquo_externo', 'obliquo_interno', 'transverso_abdomen',
  'gluteo_maximo', 'gluteo_medio', 'gluteo_minimo', 'psoas_maior', 'iliaco', 'sartorio',
  'reto_femoral', 'vasto_lateral', 'vasto_medial', 'vasto_intermedio',
  'biceps_femoral_cabeca_longa', 'biceps_femoral_cabeca_curta', 'semitendineo', 'semimembranoso',
  'gracil', 'pectineo', 'adutor_longo', 'adutor_magno', 'adutor_curto',
  'gastrocnemio_medial', 'gastrocnemio_lateral', 'soleo', 'tibial_anterior',
] as const;

export type GlbMuscleNodeId = (typeof GLB_MUSCLE_NODE_IDS)[number];

export interface MuscleMeshEntry {
  /** Nós do GLB destacados quando este músculo é primário ou secundário. Vazio = sem malha. */
  nodes: readonly GlbMuscleNodeId[];
  /** O destaque cobre mais do que o músculo descrito (o modelo não separa porções, ou o termo é de grupo). */
  approximate?: boolean;
  note?: string;
  needsReview: true;
}

const e = (nodes: readonly GlbMuscleNodeId[], extra: Partial<Omit<MuscleMeshEntry, 'nodes' | 'needsReview'>> = {}): MuscleMeshEntry => ({
  nodes,
  needsReview: true,
  ...extra,
});

const SEM_MALHA = (note: string): MuscleMeshEntry => e([], { note });

export const MUSCLE_MESH_MAP: Record<CanonicalMuscleId, MuscleMeshEntry> = {
  // Peito
  peitoral_maior: e(['peitoral_esternocostal', 'peitoral_clavicular']),
  peitoral_maior_clavicular: e(['peitoral_clavicular']),
  peitoral_maior_esternal: e(['peitoral_esternocostal'], { approximate: true, note: 'O modelo une as porções esternal e costal.' }),
  peitoral_maior_costal: e(['peitoral_esternocostal'], { approximate: true, note: 'O modelo une as porções esternal e costal.' }),
  // Costas
  latissimo_dorso: e(['latissimo_dorso']),
  romboide: e(['romboide_maior', 'romboide_menor']),
  trapezio: e(['trapezio_superior', 'trapezio_medio', 'trapezio_inferior']),
  trapezio_superior: e(['trapezio_superior']),
  trapezio_medio: e(['trapezio_medio']),
  trapezio_inferior: e(['trapezio_inferior']),
  redondo_maior: e(['redondo_maior']),
  eretores_espinha: e(['iliocostal_lombar', 'longissimo_torax'], { approximate: true, note: 'O espinhal não está no recorte do modelo.' }),
  // Ombros
  deltoide_anterior: e(['deltoide_anterior']),
  deltoide_lateral: e(['deltoide_lateral']),
  deltoide_posterior: e(['deltoide_posterior']),
  // Braços
  biceps_braquial: e(['biceps_cabeca_longa', 'biceps_cabeca_curta']),
  biceps_cabeca_curta: e(['biceps_cabeca_curta']),
  biceps_cabeca_longa: e(['biceps_cabeca_longa']),
  braquial: e(['braquial']),
  braquiorradial: e(['braquiorradial']),
  antebraco: SEM_MALHA('O modelo não inclui os músculos do antebraço.'),
  triceps_braquial: e(['triceps_cabeca_longa', 'triceps_cabeca_lateral', 'triceps_cabeca_medial']),
  triceps_cabeca_longa: e(['triceps_cabeca_longa']),
  triceps_cabeca_lateral: e(['triceps_cabeca_lateral']),
  triceps_cabeca_medial: e(['triceps_cabeca_medial']),
  anconeo: e(['anconeo']),
  // Abdômen / core
  reto_abdominal: e(['reto_abdominal']),
  reto_abdominal_superior: e(['reto_abdominal'], { approximate: true, note: 'O modelo não separa as porções do reto abdominal.' }),
  reto_abdominal_inferior: e(['reto_abdominal'], { approximate: true, note: 'O modelo não separa as porções do reto abdominal.' }),
  obliquos: e(['obliquo_externo', 'obliquo_interno']),
  transverso_abdomem: e(['transverso_abdomen']),
  core: e(['reto_abdominal', 'obliquo_externo', 'obliquo_interno', 'transverso_abdomen'], { approximate: true, note: '"Core" é termo de grupo; o destaque reúne a musculatura abdominal do modelo.' }),
  serratil_anterior: e(['serratil_anterior']),
  // Quadríceps
  quadriceps: e(['reto_femoral', 'vasto_lateral', 'vasto_medial', 'vasto_intermedio']),
  reto_femoral: e(['reto_femoral']),
  vasto_lateral: e(['vasto_lateral']),
  vasto_medial: e(['vasto_medial']),
  vasto_intermedio: e(['vasto_intermedio']),
  // Posteriores de coxa
  isquiotibiais: e(['biceps_femoral_cabeca_longa', 'biceps_femoral_cabeca_curta', 'semitendineo', 'semimembranoso']),
  biceps_femoral: e(['biceps_femoral_cabeca_longa', 'biceps_femoral_cabeca_curta']),
  semitendineo: e(['semitendineo']),
  semimembranoso: e(['semimembranoso']),
  // Glúteos
  gluteos: e(['gluteo_maximo', 'gluteo_medio', 'gluteo_minimo'], { approximate: true, note: '"Glúteos" é termo de grupo; o destaque reúne os três glúteos.' }),
  gluteo_maximo: e(['gluteo_maximo']),
  gluteo_medio: e(['gluteo_medio']),
  gluteo_minimo: e(['gluteo_minimo']),
  // Adutores / flexores / tensores
  adutores_coxa: e(['adutor_longo', 'adutor_magno', 'adutor_curto', 'gracil', 'pectineo'], { approximate: true, note: 'O destaque reúne os adutores, o grácil e o pectíneo do modelo.' }),
  adutor_longo: e(['adutor_longo']),
  adutor_magno: e(['adutor_magno']),
  adutor_curto: e(['adutor_curto']),
  gracil: e(['gracil']),
  pectineo: e(['pectineo']),
  iliopsoas: e(['psoas_maior', 'iliaco']),
  tensor_fascia_lata: SEM_MALHA('O tensor da fáscia lata não está no recorte do modelo.'),
  // Panturrilhas
  gastrocnemio: e(['gastrocnemio_medial', 'gastrocnemio_lateral']),
  gastrocnemio_lateral: e(['gastrocnemio_lateral']),
  gastrocnemio_medial: e(['gastrocnemio_medial']),
  soleo: e(['soleo']),
};

/** Nós do GLB sem músculo canônico correspondente: aparecem na cor-base, sem destaque. */
export const UNMAPPED_NODES: readonly GlbMuscleNodeId[] = [
  'peitoral_menor', 'redondo_menor', 'infraespinhal', 'supraespinhal', 'subescapular', 'sartorio', 'tibial_anterior',
];

export interface ResolvedHighlight {
  primaryNodes: Set<GlbMuscleNodeId>;
  secondaryNodes: Set<GlbMuscleNodeId>;
  /** IDs canônicos informados que não têm malha no modelo. */
  withoutMesh: CanonicalMuscleId[];
  /** IDs canônicos cujo destaque é aproximado. */
  approximate: CanonicalMuscleId[];
}

export function resolveHighlight(
  primaryIds: readonly CanonicalMuscleId[],
  secondaryIds: readonly CanonicalMuscleId[] = [],
): ResolvedHighlight {
  const primaryNodes = new Set<GlbMuscleNodeId>();
  const secondaryNodes = new Set<GlbMuscleNodeId>();
  const withoutMesh: CanonicalMuscleId[] = [];
  const approximate: CanonicalMuscleId[] = [];

  const collect = (ids: readonly CanonicalMuscleId[], target: Set<GlbMuscleNodeId>) => {
    for (const id of ids) {
      const entry = MUSCLE_MESH_MAP[id];
      if (!entry || entry.nodes.length === 0) {
        if (!withoutMesh.includes(id)) withoutMesh.push(id);
        continue;
      }
      entry.nodes.forEach((n) => target.add(n));
      if (entry.approximate && !approximate.includes(id)) approximate.push(id);
    }
  };
  collect(primaryIds, primaryNodes);
  collect(secondaryIds, secondaryNodes);
  primaryNodes.forEach((n) => secondaryNodes.delete(n));
  return { primaryNodes, secondaryNodes, withoutMesh, approximate };
}
````

## ARQUIVO 3 — src/components/exercise-detail/MuscleViewer3D.tsx

````tsx
import React, { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { ChevronLeft, ChevronRight, Layers, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import { CANONICAL_MUSCLE_DEFINITIONS, type CanonicalMuscleId } from '../../data/muscleTaxonomy';
import { resolveHighlight, type GlbMuscleNodeId } from '../../data/muscleMeshMap';
import {
  getAnatomyModelUrl,
  pickAnatomyModelQuality,
  type AnatomyModelQuality,
} from '../../config/anatomyViewer';

/**
 * Visualizador anatômico 3D (modelo de referência masculino, derivado do Z-Anatomy / BodyParts3D,
 * CC BY-SA 4.0). Carregado sob demanda pela tela de detalhe; destaca músculos por ID canônico.
 * Renderiza sob demanda (sem laço contínuo, sem rotação automática).
 */
interface MuscleViewer3DProps {
  primaryMuscleIds: readonly CanonicalMuscleId[];
  secondaryMuscleIds?: readonly CanonicalMuscleId[];
  quality?: AnatomyModelQuality;
  className?: string;
  /** Chamado quando o 3D não pode ser usado (sem WebGL, falha de carga, perda de contexto). */
  onUnavailable?: (reason: string) => void;
}

type ViewState = 'loading' | 'ready' | 'error';
type ViewPreset = 'front' | 'back';

const NODE_NAME = /^muscle-(.+)-(l|r)-\d+$/;
const ORBIT_STEP = Math.PI / 12;
const POLAR_MIN = Math.PI * 0.28;
const POLAR_MAX = Math.PI * 0.72;

interface SharedMaterials {
  base: THREE.MeshStandardMaterial;
  ghost: THREE.MeshStandardMaterial;
  primary: THREE.MeshStandardMaterial;
  secondary: THREE.MeshStandardMaterial;
}

const label = (id: CanonicalMuscleId) => CANONICAL_MUSCLE_DEFINITIONS[id]?.labelPtBr ?? id;

const controlButton =
  'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ' +
  'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 ' +
  'hover:bg-slate-200 dark:hover:bg-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500';

export const MuscleViewer3D: React.FC<MuscleViewer3DProps> = ({
  primaryMuscleIds,
  secondaryMuscleIds = [],
  quality,
  className = '',
  onUnavailable,
}) => {
  const summaryId = useId();
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshesRef = useRef<Map<GlbMuscleNodeId, THREE.Mesh[]>>(new Map());
  const materialsRef = useRef<SharedMaterials | null>(null);
  const frontRef = useRef(new THREE.Vector3(0, 0, 1));
  const fitRef = useRef({ center: new THREE.Vector3(), distance: 3 });
  const rafRef = useRef<number | null>(null);
  const onUnavailableRef = useRef(onUnavailable);
  onUnavailableRef.current = onUnavailable;

  const [state, setState] = useState<ViewState>('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const [isolate, setIsolate] = useState(false);

  const effectiveQuality = useMemo(() => quality ?? pickAnatomyModelQuality(), [quality]);
  const highlight = useMemo(
    () => resolveHighlight(primaryMuscleIds, secondaryMuscleIds),
    [primaryMuscleIds, secondaryMuscleIds],
  );

  const requestRender = useCallback(() => {
    if (rafRef.current !== null) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      const renderer = rendererRef.current;
      const scene = sceneRef.current;
      const camera = cameraRef.current;
      if (renderer && scene && camera) renderer.render(scene, camera);
    });
  }, []);

  // ---- Inicialização: renderer, cena, GLB ----
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let disposed = false;
    setState('loading');
    setErrorMessage('');

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    } catch {
      setErrorMessage('O modelo 3D precisa de WebGL, indisponível neste dispositivo.');
      setState('error');
      onUnavailableRef.current?.('webgl');
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const canvas = renderer.domElement;
    canvas.setAttribute('aria-hidden', 'true');
    canvas.style.display = 'block';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    container.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(28, 1, 0.01, 50);
    // Luz presa à câmera: a frente e as costas ficam iluminadas em qualquer ângulo.
    const headlight = new THREE.DirectionalLight(0xffffff, 2.4);
    headlight.position.set(0.6, 1.2, 2);
    camera.add(headlight);
    scene.add(camera);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x4b5563, 1.1));

    const controls = new OrbitControls(camera, canvas);
    controls.enablePan = false;
    controls.enableDamping = false; // sem inércia: respeita prefers-reduced-motion e economiza bateria
    controls.rotateSpeed = 0.8;
    controls.minPolarAngle = POLAR_MIN;
    controls.maxPolarAngle = POLAR_MAX;
    controls.addEventListener('change', requestRender);
    // O OrbitControls força touch-action:none; 'pan-y' devolve a rolagem vertical da página ao celular.
    canvas.style.touchAction = 'pan-y';

    rendererRef.current = renderer;
    sceneRef.current = scene;
    cameraRef.current = camera;
    controlsRef.current = controls;

    const resize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w === 0 || h === 0) return;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      requestRender();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(container);
    resize();

    const onContextLost = (ev: Event) => {
      ev.preventDefault();
      setErrorMessage('A visualização 3D foi interrompida pelo navegador.');
      setState('error');
      onUnavailableRef.current?.('context-lost');
    };
    canvas.addEventListener('webglcontextlost', onContextLost);

    const loader = new GLTFLoader();
    loader.setMeshoptDecoder(MeshoptDecoder);
    loader
      .loadAsync(getAnatomyModelUrl(effectiveQuality))
      .then((gltf) => {
        if (disposed) {
          disposeObject(gltf.scene);
          return;
        }
        const root = gltf.scene;
        scene.add(root);

        const byNode = new Map<GlbMuscleNodeId, THREE.Mesh[]>();
        root.traverse((obj) => {
          const mesh = obj as THREE.Mesh;
          if (!mesh.isMesh) return;
          let cursor: THREE.Object3D | null = mesh;
          while (cursor) {
            const match = NODE_NAME.exec(cursor.name);
            if (match) {
              const id = match[1] as GlbMuscleNodeId;
              const list = byNode.get(id) ?? [];
              list.push(mesh);
              byNode.set(id, list);
              return;
            }
            cursor = cursor.parent;
          }
        });
        meshesRef.current = byNode;

        const base = new THREE.MeshStandardMaterial({ color: 0xb3a79c, roughness: 0.62, metalness: 0 });
        const ghost = base.clone();
        ghost.transparent = true;
        ghost.opacity = 0.15;
        ghost.depthWrite = false;
        const primary = new THREE.MeshStandardMaterial({ color: 0xe11d48, emissive: 0x7f1d1d, emissiveIntensity: 0.45, roughness: 0.5 });
        const secondary = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0x78350f, emissiveIntensity: 0.35, roughness: 0.5 });
        materialsRef.current = { base, ghost, primary, secondary };

        // Frente do modelo: do centroide do latíssimo (costas) para o do peitoral (frente), no plano horizontal.
        const centroid = (id: GlbMuscleNodeId) => {
          const meshes = byNode.get(id);
          if (!meshes?.length) return null;
          const box = new THREE.Box3();
          meshes.forEach((m) => box.expandByObject(m));
          return box.getCenter(new THREE.Vector3());
        };
        const chest = centroid('peitoral_esternocostal');
        const back = centroid('latissimo_dorso');
        const front = new THREE.Vector3(0, 0, 1);
        if (chest && back) {
          const d = chest.sub(back);
          d.y = 0;
          if (d.lengthSq() > 1e-8) front.copy(d.normalize());
        }
        frontRef.current = front;

        const box = new THREE.Box3().setFromObject(root);
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        const fov = THREE.MathUtils.degToRad(camera.fov);
        const distH = size.y / 2 / Math.tan(fov / 2);
        const distW = size.x / 2 / (Math.tan(fov / 2) * Math.max(camera.aspect, 0.1));
        const distance = Math.max(distH, distW) * 1.12;
        fitRef.current = { center, distance };
        controls.minDistance = distance * 0.5;
        controls.maxDistance = distance * 1.6;

        camera.position.copy(center).addScaledVector(front, distance);
        controls.target.copy(center);
        controls.update();
        setState('ready');
        requestRender();
      })
      .catch(() => {
        if (disposed) return;
        setErrorMessage('Não foi possível carregar o modelo 3D.');
        setState('error');
        onUnavailableRef.current?.('load');
      });

    return () => {
      disposed = true;
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      observer.disconnect();
      canvas.removeEventListener('webglcontextlost', onContextLost);
      controls.removeEventListener('change', requestRender);
      controls.dispose();
      disposeObject(scene);
      const mats = materialsRef.current;
      if (mats) {
        mats.base.dispose();
        mats.ghost.dispose();
        mats.primary.dispose();
        mats.secondary.dispose();
      }
      materialsRef.current = null;
      meshesRef.current = new Map();
      renderer.dispose();
      renderer.forceContextLoss();
      if (canvas.parentNode === container) container.removeChild(canvas);
      rendererRef.current = null;
      sceneRef.current = null;
      cameraRef.current = null;
      controlsRef.current = null;
    };
  }, [effectiveQuality, requestRender]);

  // ---- Destaque por estado (sem recarregar o modelo ao trocar de exercício) ----
  useEffect(() => {
    if (state !== 'ready') return;
    const mats = materialsRef.current;
    if (!mats) return;
    const anyActive = highlight.primaryNodes.size + highlight.secondaryNodes.size > 0;
    meshesRef.current.forEach((meshes, nodeId) => {
      const material = highlight.primaryNodes.has(nodeId)
        ? mats.primary
        : highlight.secondaryNodes.has(nodeId)
          ? mats.secondary
          : isolate && anyActive
            ? mats.ghost
            : mats.base;
      meshes.forEach((m) => {
        m.material = material;
      });
    });
    requestRender();
  }, [state, highlight, isolate, requestRender]);

  // ---- Câmera: vistas, órbita e zoom ----
  const setView = useCallback(
    (preset: ViewPreset) => {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;
      const { center, distance } = fitRef.current;
      const dir = frontRef.current.clone();
      if (preset === 'back') dir.negate();
      camera.position.copy(center).addScaledVector(dir, distance);
      controls.target.copy(center);
      controls.update();
      requestRender();
    },
    [requestRender],
  );

  const orbit = useCallback(
    (deltaTheta: number, deltaPhi: number) => {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;
      const offset = camera.position.clone().sub(controls.target);
      const spherical = new THREE.Spherical().setFromVector3(offset);
      spherical.theta += deltaTheta;
      spherical.phi = THREE.MathUtils.clamp(spherical.phi + deltaPhi, POLAR_MIN, POLAR_MAX);
      camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(spherical));
      controls.update();
      requestRender();
    },
    [requestRender],
  );

  const zoom = useCallback(
    (factor: number) => {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;
      const offset = camera.position.clone().sub(controls.target);
      const length = THREE.MathUtils.clamp(offset.length() * factor, controls.minDistance, controls.maxDistance);
      camera.position.copy(controls.target).add(offset.setLength(length));
      controls.update();
      requestRender();
    },
    [requestRender],
  );

  const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (state !== 'ready') return;
    switch (e.key) {
      case 'ArrowLeft': orbit(-ORBIT_STEP, 0); break;
      case 'ArrowRight': orbit(ORBIT_STEP, 0); break;
      case 'ArrowUp': orbit(0, -ORBIT_STEP / 2); break;
      case 'ArrowDown': orbit(0, ORBIT_STEP / 2); break;
      case '+': case '=': zoom(0.85); break;
      case '-': case '_': zoom(1.18); break;
      case 'Home': setView('front'); break;
      default: return;
    }
    e.preventDefault();
  };

  const summary = useMemo(() => {
    const names = (ids: readonly CanonicalMuscleId[]) => (ids.length ? ids.map(label).join(', ') : 'não informado');
    const parts = [`Primário: ${names(primaryMuscleIds)}.`, `Secundário: ${names(secondaryMuscleIds)}.`];
    if (highlight.withoutMesh.length) parts.push(`Sem destaque no modelo 3D: ${highlight.withoutMesh.map(label).join(', ')}.`);
    if (highlight.approximate.length) parts.push(`Destaque aproximado para: ${highlight.approximate.map(label).join(', ')}.`);
    return parts.join(' ');
  }, [primaryMuscleIds, secondaryMuscleIds, highlight]);

  const ready = state === 'ready';

  return (
    <section aria-label="Modelo anatômico 3D dos músculos" className={`space-y-2 ${className}`}>
      <div
        ref={containerRef}
        role="group"
        tabIndex={0}
        aria-label="Modelo 3D. Use as setas para girar, mais e menos para aproximar e Home para voltar à vista frontal."
        aria-describedby={summaryId}
        onKeyDown={onKeyDown}
        className="relative h-72 sm:h-80 rounded-2xl overflow-hidden bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500"
      >
        {state === 'loading' && (
          <div role="status" className="absolute inset-0 flex items-center justify-center animate-pulse text-xs font-bold text-slate-600 dark:text-slate-300">
            Carregando modelo 3D…
          </div>
        )}
        {state === 'error' && (
          <div role="status" className="absolute inset-0 flex items-center justify-center px-6 text-center text-xs font-bold text-slate-700 dark:text-slate-200">
            {errorMessage}
          </div>
        )}
      </div>

      <p id={summaryId} className="sr-only">{summary}</p>

      <div className="flex flex-wrap items-center gap-2" aria-label="Controles do modelo 3D" role="group">
        <button type="button" disabled={!ready} onClick={() => orbit(-ORBIT_STEP, 0)} aria-label="Girar para a esquerda" className={controlButton}>
          <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
        <button type="button" disabled={!ready} onClick={() => orbit(ORBIT_STEP, 0)} aria-label="Girar para a direita" className={controlButton}>
          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
        <button type="button" disabled={!ready} onClick={() => zoom(0.85)} aria-label="Aproximar" className={controlButton}>
          <ZoomIn className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
        <button type="button" disabled={!ready} onClick={() => zoom(1.18)} aria-label="Afastar" className={controlButton}>
          <ZoomOut className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
        <button type="button" disabled={!ready} onClick={() => setView('front')} className={controlButton}>Frente</button>
        <button type="button" disabled={!ready} onClick={() => setView('back')} className={controlButton}>Costas</button>
        <button type="button" disabled={!ready} onClick={() => setView('front')} aria-label="Redefinir vista" className={controlButton}>
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
        <button
          type="button"
          disabled={!ready}
          aria-pressed={isolate}
          onClick={() => setIsolate((v) => !v)}
          className={`${controlButton} ${isolate ? 'ring-2 ring-cyan-500' : ''}`}
        >
          <Layers className="w-3.5 h-3.5" aria-hidden="true" />
          Isolar músculos ativos
        </button>
      </div>

      <ul className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-bold text-slate-700 dark:text-slate-200" aria-label="Legenda">
        <li className="inline-flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-sm bg-rose-600 border border-rose-900" aria-hidden="true" /> Primário
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-sm bg-amber-500 border border-amber-800" aria-hidden="true" /> Secundário
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-sm bg-stone-400 border border-stone-600" aria-hidden="true" /> Demais músculos
        </li>
      </ul>

      {(highlight.withoutMesh.length > 0 || highlight.approximate.length > 0) && (
        <p className="text-[11px] text-slate-700 dark:text-slate-300">
          {highlight.withoutMesh.length > 0 && <>Sem destaque no modelo 3D: {highlight.withoutMesh.map(label).join(', ')}. </>}
          {highlight.approximate.length > 0 && <>Destaque aproximado para: {highlight.approximate.map(label).join(', ')}.</>}
        </p>
      )}

      <p className="text-[11px] text-slate-600 dark:text-slate-400">
        Modelo anatômico de referência (masculino), adaptado do{' '}
        <a
          href="https://github.com/Z-Anatomy/Models-of-human-anatomy"
          target="_blank"
          rel="noopener noreferrer"
          className="underline focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded"
        >
          Z-Anatomy<span className="sr-only"> (abre em nova aba)</span>
        </a>{' '}
        (licença{' '}
        <a
          href="https://creativecommons.org/licenses/by-sa/4.0/"
          target="_blank"
          rel="noopener noreferrer"
          className="underline focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded"
        >
          CC BY-SA 4.0<span className="sr-only"> (abre em nova aba)</span>
        </a>
        ), com base no BodyParts3D. Modelo modificado: músculos selecionados, malha simplificada e nós renomeados.
      </p>
    </section>
  );
};

function disposeObject(root: THREE.Object3D) {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.geometry?.dispose();
      const material = mesh.material;
      if (Array.isArray(material)) material.forEach((m) => m.dispose());
      else material?.dispose();
    }
  });
}

export default MuscleViewer3D;
````

## ARQUIVO 4 — scripts/glbUtils.ts

````typescript
import { readFileSync } from 'node:fs';

export interface GlbJson {
  asset?: { version?: string };
  extensionsUsed?: string[];
  nodes?: { name?: string; mesh?: number }[];
  meshes?: unknown[];
}

/** Lê somente o chunk JSON do GLB (sem decodificar malhas; funciona com compressão meshopt). */
export function readGlbJson(path: string): GlbJson & { byteLength: number } {
  const buf = readFileSync(path);
  if (buf.toString('ascii', 0, 4) !== 'glTF') throw new Error(`${path}: cabeçalho glTF ausente`);
  const version = buf.readUInt32LE(4);
  if (version !== 2) throw new Error(`${path}: versão glTF ${version}; esperado 2`);
  const jsonLength = buf.readUInt32LE(12);
  const chunkType = buf.toString('ascii', 16, 20);
  if (chunkType !== 'JSON') throw new Error(`${path}: primeiro chunk não é JSON (${chunkType})`);
  const json = JSON.parse(buf.toString('utf8', 20, 20 + jsonLength)) as GlbJson;
  return { ...json, byteLength: buf.length };
}

export const MUSCLE_NODE_PATTERN = /^muscle-(.+)-(l|r)-(\d+)$/;

export interface MuscleNodeInfo {
  id: string;
  side: 'l' | 'r';
  name: string;
}

export function readMuscleNodes(path: string) {
  const json = readGlbJson(path);
  const meshNodes = (json.nodes ?? []).filter((n) => typeof n.mesh === 'number');
  const valid: MuscleNodeInfo[] = [];
  const invalid: string[] = [];
  for (const node of meshNodes) {
    const name = node.name ?? '(sem nome)';
    const m = MUSCLE_NODE_PATTERN.exec(name);
    if (m) valid.push({ id: m[1], side: m[2] as 'l' | 'r', name });
    else invalid.push(name);
  }
  return { json, valid, invalid, totalNodes: (json.nodes ?? []).length, meshNodes: meshNodes.length };
}
````

## ARQUIVO 5 — scripts/listGlbNodes.ts

````typescript
import { readMuscleNodes } from './glbUtils';

const files = process.argv.slice(2);
const targets = files.length ? files : ['public/models/muscles.min.glb', 'public/models/muscles.low.glb'];

for (const file of targets) {
  const info = readMuscleNodes(file);
  const ids = new Map<string, { l: number; r: number }>();
  for (const n of info.valid) {
    const entry = ids.get(n.id) ?? { l: 0, r: 0 };
    entry[n.side] += 1;
    ids.set(n.id, entry);
  }
  console.log(`\n== ${file} ==`);
  console.log(`bytes: ${info.json.byteLength} | glTF ${info.json.asset?.version} | extensões: ${(info.json.extensionsUsed ?? []).join(', ') || '(nenhuma)'}`);
  console.log(`nós: ${info.totalNodes} | nós com malha: ${info.meshNodes} | no padrão muscle-<id>-<l|r>-<n>: ${info.valid.length} | fora do padrão: ${info.invalid.length}`);
  console.log(`IDs distintos: ${ids.size}`);
  [...ids.entries()].sort().forEach(([id, c]) => console.log(`  ${id.padEnd(30)} l=${c.l} r=${c.r}`));
  if (info.invalid.length) console.log('fora do padrão:', info.invalid.join(', '));
}
````

## ARQUIVO 6 — scripts/verifyMuscle3d.ts

````typescript
import { CANONICAL_MUSCLE_IDS } from '../src/data/muscleTaxonomy';
import { GLB_MUSCLE_NODE_IDS, MUSCLE_MESH_MAP, UNMAPPED_NODES, resolveHighlight } from '../src/data/muscleMeshMap';
import { EXTENDED_EXERCISE_LIBRARY } from '../src/data/exerciseLibraryData';
import { readMuscleNodes } from './glbUtils';

const errors: string[] = [];
const fail = (msg: string) => errors.push(msg);
const GLBS = ['public/models/muscles.min.glb', 'public/models/muscles.low.glb'];
const declared = new Set<string>(GLB_MUSCLE_NODE_IDS);

// 1) GLBs: cabeçalho válido, nós no padrão, mesmo conjunto de IDs que o declarado, ambos os lados
const idSets: Record<string, Set<string>> = {};
for (const file of GLBS) {
  const info = readMuscleNodes(file);
  if (info.invalid.length) fail(`${file}: nós de malha fora do padrão: ${info.invalid.join(', ')}`);
  const sides = new Map<string, Set<string>>();
  info.valid.forEach((n) => sides.set(n.id, (sides.get(n.id) ?? new Set()).add(n.side)));
  idSets[file] = new Set(sides.keys());
  for (const id of sides.keys()) if (!declared.has(id)) fail(`${file}: nó '${id}' não declarado em GLB_MUSCLE_NODE_IDS`);
  for (const id of declared) {
    if (!sides.has(id)) fail(`${file}: ID declarado '${id}' ausente no GLB`);
    else if (sides.get(id)!.size !== 2) fail(`${file}: ID '${id}' sem os dois lados (l e r)`);
  }
  console.log(`[verify:muscle3d] ${file}: ${info.valid.length} nós de músculo, ${sides.size} IDs distintos`);
}
if (idSets[GLBS[0]].size !== idSets[GLBS[1]].size) fail('GLBs com quantidade de IDs diferente entre as qualidades');

// 2) Mapa: só referencia nós existentes; todo nó do GLB é referenciado ou está em UNMAPPED_NODES
const referenced = new Set<string>();
for (const [canonical, entry] of Object.entries(MUSCLE_MESH_MAP)) {
  entry.nodes.forEach((n) => {
    referenced.add(n);
    if (!declared.has(n)) fail(`MUSCLE_MESH_MAP['${canonical}'] referencia nó inexistente '${n}'`);
  });
}
for (const id of declared) {
  const isUnmapped = (UNMAPPED_NODES as readonly string[]).includes(id);
  if (!referenced.has(id) && !isUnmapped) fail(`nó '${id}' do GLB sem músculo canônico e fora de UNMAPPED_NODES`);
  if (referenced.has(id) && isUnmapped) fail(`nó '${id}' está em UNMAPPED_NODES mas é referenciado pelo mapa`);
}

// 3) Taxonomia: todo ID canônico tem entrada; listar os sem malha
const withoutMesh: string[] = [];
for (const id of CANONICAL_MUSCLE_IDS) {
  const entry = MUSCLE_MESH_MAP[id];
  if (!entry) fail(`ID canônico '${id}' sem entrada em MUSCLE_MESH_MAP`);
  else if (entry.nodes.length === 0) withoutMesh.push(id);
}

// 4) Cobertura por exercício (informativa): músculos primários com malha
let full = 0, partial = 0, none = 0, noIds = 0;
const noneList: string[] = [];
for (const ex of EXTENDED_EXERCISE_LIBRARY) {
  const ids = ex.primaryMuscleIds ?? [];
  if (ids.length === 0) { noIds += 1; fail(`exercício '${ex.id}' sem primaryMuscleIds`); continue; }
  const r = resolveHighlight(ids, ex.secondaryMuscleIds ?? []);
  const covered = ids.filter((id) => (MUSCLE_MESH_MAP[id]?.nodes.length ?? 0) > 0).length;
  if (covered === ids.length) full += 1;
  else if (covered > 0) partial += 1;
  else { none += 1; noneList.push(ex.id); }
  void r;
}

console.log(`[verify:muscle3d] IDs canônicos: ${CANONICAL_MUSCLE_IDS.length} | com malha: ${CANONICAL_MUSCLE_IDS.length - withoutMesh.length} | sem malha: ${withoutMesh.length} (${withoutMesh.join(', ') || '-'})`);
console.log(`[verify:muscle3d] nós do GLB: ${declared.size} | referenciados pelo mapa: ${referenced.size} | em UNMAPPED_NODES: ${UNMAPPED_NODES.length}`);
console.log(`[verify:muscle3d] exercícios: ${EXTENDED_EXERCISE_LIBRARY.length} | primários 100% com malha: ${full} | parcial: ${partial} | nenhum: ${none}${noneList.length ? ' (' + noneList.join(', ') + ')' : ''} | sem IDs: ${noIds}`);

if (errors.length) {
  console.error(`[verify:muscle3d] FALHA (${errors.length}):`);
  errors.forEach((e) => console.error('  - ' + e));
  process.exit(1);
}
console.log('[verify:muscle3d] SUCESSO');
````

## ARQUIVO 7 — scripts/smokeGlbLoad.ts

````typescript
/**
 * Teste de fumaça em Node: decodifica o GLB (meshopt) com o mesmo GLTFLoader do app e confere
 * nós, vértices, caixa delimitadora e a detecção de "frente" usada pelo visualizador.
 * Não substitui o teste em navegador (WebGL) nem em celular.
 */
import { readFileSync } from 'node:fs';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';

const NODE_NAME = /^muscle-(.+)-(l|r)-\d+$/;
const files = process.argv.slice(2);
const targets = files.length ? files : ['public/models/muscles.min.glb', 'public/models/muscles.low.glb'];
let failed = false;

for (const file of targets) {
  const buf = readFileSync(file);
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  const loader = new GLTFLoader();
  loader.setMeshoptDecoder(MeshoptDecoder);
  const gltf = await new Promise<{ scene: THREE.Group }>((resolve, reject) => loader.parse(ab, '', resolve, reject));

  const byId = new Map<string, THREE.Mesh[]>();
  const nodeNames = new Set<string>();
  let vertices = 0;
  gltf.scene.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    vertices += mesh.geometry.getAttribute('position').count;
    let cursor: THREE.Object3D | null = mesh;
    while (cursor) {
      const m = NODE_NAME.exec(cursor.name);
      if (m) {
        byId.set(m[1], [...(byId.get(m[1]) ?? []), mesh]);
        nodeNames.add(cursor.name);
        return;
      }
      cursor = cursor.parent;
    }
  });

  const box = new THREE.Box3().setFromObject(gltf.scene);
  const size = box.getSize(new THREE.Vector3());
  const centroid = (id: string) => {
    const meshes = byId.get(id);
    if (!meshes?.length) return null;
    const b = new THREE.Box3();
    meshes.forEach((m) => b.expandByObject(m));
    return b.getCenter(new THREE.Vector3());
  };
  const chest = centroid('peitoral_esternocostal');
  const back = centroid('latissimo_dorso');
  const front = new THREE.Vector3(0, 0, 1);
  if (chest && back) {
    const d = chest.sub(back);
    d.y = 0;
    if (d.lengthSq() > 1e-8) front.copy(d.normalize());
  }
  const meshCount = [...byId.values()].reduce((n, l) => n + l.length, 0); // primitivas (um nó pode ter mais de uma)
  console.log(`\n== ${file} ==`);
  console.log(`nós de músculo: ${nodeNames.size} | primitivas (malhas three.js): ${meshCount} | IDs: ${byId.size} | vértices decodificados: ${vertices}`);
  console.log(`caixa (m): ${size.x.toFixed(3)} x ${size.y.toFixed(3)} x ${size.z.toFixed(3)} | altura é o eixo Y: ${size.y > size.x && size.y > size.z}`);
  console.log(`frente detectada: (${front.x.toFixed(2)}, ${front.y.toFixed(2)}, ${front.z.toFixed(2)})`);
  if (nodeNames.size !== 112 || byId.size !== 55 || !(size.y > size.x && size.y > size.z)) {
    failed = true;
    console.error('FALHA: contagem ou orientação inesperada');
  }
}
if (failed) process.exit(1);
console.log('\n[smoke:glb] SUCESSO');
````

## ARQUIVO 8 — docs/licenca-modelos-3d.md

````markdown
# Licença e atribuição dos modelos 3D (RASCUNHO — pendente de revisão jurídica)

## Origem
- Z-Anatomy: https://github.com/Z-Anatomy/Models-of-human-anatomy (licença CC BY-SA 4.0).
- O Z-Anatomy se baseia no BodyParts3D, © The Database Center for Life Science, licenciado sob CC BY-SA 2.1 Japão. (Confirmar o link oficial do BodyParts3D antes de publicar.)
- Modelo masculino de referência. Origem dos arquivos: `Z-Anatomy.zip` (template do Blender, `Startup.blend`).

## Modificações feitas
- Seleção de 112 malhas musculares (55 músculos, lados direito e esquerdo); componentes com licença não comercial do pacote não foram usados.
- Simplificação de polígonos (25% e 10% dos originais).
- Remoção da hierarquia de grupos e renomeação dos nós para `muscle-<id>-<l|r>-<n>`.
- Exportação em GLB, quantização e compressão meshopt.

## Arquivos derivados
- `public/models/muscles.min.glb` (padrão) e `public/models/muscles.low.glb` (economia de dados).
- Estes arquivos derivados são distribuídos sob CC BY-SA 4.0, com atribuição ao Z-Anatomy e ao BodyParts3D.

## Onde a atribuição aparece
- Abaixo do visualizador 3D, na tela de detalhe do exercício (`MuscleViewer3D.tsx`), com links para o Z-Anatomy e para a licença CC BY-SA 4.0.

## Pendências
- Revisão jurídica: relação entre o aplicativo e o modelo derivado sob CC BY-SA (obras separadas ou adaptação), e redistribuição dos GLBs.
- Revisão por profissional de educação física: recorte de músculos, nomenclatura e equivalências em `src/data/muscleMeshMap.ts`.
- Modelo feminino não disponível.
````

---

# EDIÇÕES EM ExerciseDetailPage.tsx (trocar ANTIGO por NOVO; cada ANTIGO ocorre uma vez)

## E1

ANTIGO:
````
import React from 'react';
````

NOVO:
````
import React, { Suspense, lazy, useMemo, useState } from 'react';
````

## E2

ANTIGO:
````
import { ExerciseCarousel } from './ExerciseCarousel';
````

NOVO:
````
import { ExerciseCarousel } from './ExerciseCarousel';
import { getAnatomyViewerMode } from '../../config/anatomyViewer';
````

## E3

ANTIGO:
````
interface ExerciseDetailPageProps {
````

NOVO:
````
/** Visualizador 3D em chunk separado: só é baixado quando o modo '3d' está ativo. */
const MuscleViewer3D = lazy(() => import('./MuscleViewer3D'));

interface ExerciseDetailPageProps {
````

## E4

ANTIGO:
````
  const visual = getMuscleGroupVisual(exercise.muscleGroup);

````

NOVO:
````
  const visual = getMuscleGroupVisual(exercise.muscleGroup);

  // Visualizador 3D (liberação em etapas): padrão 'images'; '3d' só com ?visual=3d ou localStorage.
  const viewerMode = useMemo(() => getAnatomyViewerMode(), []);
  const [viewer3dUnavailable, setViewer3dUnavailable] = useState(false);
  const show3d = viewerMode === '3d' && !viewer3dUnavailable && (exercise.primaryMuscleIds?.length ?? 0) > 0;

````

## E5

ANTIGO:
````
            <ExerciseVisualStage
              animationType={exercise.animation3dType}
              muscleGroup={exercise.muscleGroup}
              mode="demo"
              allowModeSwitch
              className="h-72 sm:h-80"
            />
            {(exercise.imageUrl || exercise.videoUrl) && (
````

NOVO:
````
            {show3d ? (
              <Suspense
                fallback={
                  <div
                    role="status"
                    className="h-72 sm:h-80 rounded-2xl flex items-center justify-center bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 animate-pulse"
                  >
                    Carregando modelo 3D…
                  </div>
                }
              >
                <MuscleViewer3D
                  primaryMuscleIds={exercise.primaryMuscleIds ?? []}
                  secondaryMuscleIds={exercise.secondaryMuscleIds ?? []}
                  onUnavailable={() => setViewer3dUnavailable(true)}
                />
              </Suspense>
            ) : (
              <ExerciseVisualStage
                animationType={exercise.animation3dType}
                muscleGroup={exercise.muscleGroup}
                mode="demo"
                allowModeSwitch
                className="h-72 sm:h-80"
              />
            )}
            {!show3d && (exercise.imageUrl || exercise.videoUrl) && (
````
